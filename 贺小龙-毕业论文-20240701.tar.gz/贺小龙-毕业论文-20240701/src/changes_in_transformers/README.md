为了实现论文提出的基于提示模板的自反馈加速策略，需要在模型推理过程中加入缓存，由于本文的模型都是基于transformers库
加载的，所以需要对transformers的源码进行修改，本文件夹中包含修改后的源码。

utils.py替换transformers源码中generation/utils.py文件
/workspace/S/hexiaolong/anaconda3/envs/new_codex/lib/python3.9/site-packages/transformers/generation/utils.py

modeling_llama.py替换库中models/llama/modeling_llama.py
/workspace/S/hexiaolong/anaconda3/envs/new_codex/lib/python3.9/site-packages/transformers/models/llama/modeling_llama.py

这个修改对llama和codellama模型是有效的，codellama模型使用的也是models/llama/modeling_llama.py中的模型结构