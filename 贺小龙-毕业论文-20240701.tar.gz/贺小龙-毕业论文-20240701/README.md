# 贺小龙-毕业论文

## 文件结构
benchmarks为使用的基准测试的文件，在原始的基准测试文件上进行了处理，统一了不同基准测试的格式。
configs为使用的设置文件
humaneval为humaneval数据集文件
images为论文中使用的图片
prompt为代码生成时使用的prompt，需要适当的修改源码中prompt的路径
res存放了代码生成结果
src为项目源码
tools为一些结果分析和绘图代码，其中show_debug_process.py为结果绘图代码，由它绘制了论文中的结果折线图
short-job.slurm为提交到集群上的slurm脚本

## 运行脚本
以下为运行命令行的示例：
python3.9 main.py +model_path=/lustre/S/hexiaolong/vicuna-7b-16k +output=../res/humanevalTS_UT_I1_F10_S10_vicuna7b16k.jsonl +sample_num=10 +filter_num=10 +first_num=1 +Strategy=TS +feedback_type=UT +dataset=humaneval > ../log/humanevalTS_UT_I1_F10_S10_vicuna7b16k.out 2>&1

其中：
model_path为模型路径
output为结果文件路径
sample_num为每次生成的候选代码数量
filter_num为每次选择的候选代码数量
first_num为初始生成的候选代码数量
Strategy为使用的自反馈策略，TS表示树搜索，NTS表示非树搜索，TFTF为测试用例筛选的自反馈
feedback_type为反馈类型，UT表示测试用例反馈，一般都是用这个
dataset为基准测试，包括humaneval，mbpp，mtpb，bigbench